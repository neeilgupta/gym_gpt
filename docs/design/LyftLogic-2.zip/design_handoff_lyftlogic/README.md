# Handoff: LyftLogic Frontend

## Overview
LyftLogic is a workout and meal planning app. Users describe what they want (goal, days/week, equipment, time, allergies), and the app produces a weekly plan they can view, edit in plain English, save, and version. This handoff covers six screens that together form the core product surface.

## About the Design Files
The files in this bundle are **design references created in HTML/React (with inline Babel)** — prototypes showing intended look and behavior, not production code to copy directly.

Your job is to **recreate these designs in your target codebase using its existing patterns and libraries** (React + Tailwind, Next.js, Vue, etc.). If you don't have a frontend yet, pick whatever framework fits the rest of the stack — these designs map cleanly onto any modern component-based UI library.

Do not ship `LyftLogic Redesign.html` as-is. It uses a sandbox design-canvas wrapper, inline JSX via Babel, and CDN React — none of which belong in production.

## Fidelity
**High-fidelity.** Final colors, typography, spacing, borders, layout, and copy are all locked. Use exact values from the Design Tokens section. Hover/active states are not designed yet — apply reasonable defaults that match the visual language (subtle background tint on hover, slightly darker accent on active).

## Screens / Views

### 1. Landing (`Landing` component)
- **Purpose**: Marketing splash. Two CTAs: "Get started" and "Sign in".
- **Layout**: Top nav (48px tall, sticky) + centered single-column main (max-width 900px, ~120px top padding).
- **Components**:
  - **Top nav**: wordmark (left) + nav links (Plans / Generate / Nutrition / Settings) + user email + avatar (right). All using mono font for nav links. 48px height, 0.5px border-bottom.
  - **Hero headline**: 68px, weight 500, letter-spacing −0.035em, line-height 1.02. Two lines — second line in `--ll-muted` color. Current copy: "Workout and meal plans, / built for you."
  - **Sub copy**: 16px, line-height 1.6, muted color, max-width 520px. Current copy: "Tell us your goal, your gear, and how much time you have. We'll build a weekly plan you can edit, save, and come back to."
  - **Buttons**: Primary (filled ink color) "Get started →" and secondary (outlined) "Sign in". 36px height, 16px horizontal padding, 12.5px mono font.

### 2. Plan viewer (`PlanViewer` component) — **the hero screen**
- **Purpose**: View and edit a generated workout plan. Browse versions, see what changed, see the week at a glance, drill into a day's exercises, and edit by chatting.
- **Layout**: 3-column grid `200px / 1fr / 320px`, full viewport height, all three columns scroll independently.
- **Left rail (200px)**:
  - "Plan" eyebrow + plan id (mono, e.g. `p_4f9b`)
  - "History" eyebrow + list of versions. Each row: `v{n}` (mono, accent if active), version note (12px), timestamp (mono, faint). Active version has tinted background. Current version shows a "NOW" pill.
- **Center column**: scrollable, 24px/32px padding.
  - **Header**: Eyebrow "Workout plan" + h1 title (22px, weight 500). Right side: "Restore v{n}" (secondary) if viewing old version, "Edit plan" (primary).
  - **Meta strip**: 6-column grid card. Cells: Goal, Level, Days/wk, Session, Equipment, Version. Each cell has a tiny mono eyebrow label and a value (16px, mono for numbers, sans for words).
  - **Diff strip** (only if `data.diff` exists): "What changed" eyebrow + counts: `+N added` (green), `~N replaced` (accent), `−N removed` (red). Right side shows the latest version note.
  - **Day tabs**: 7-column grid. Each tab shows `01·MON` (mono, tiny) + focus label. Selected tab inverts (ink bg, bg color text). Rest days are dimmer.
  - **Day table**: 6-column grid `32px / 1fr / 80px / 90px / 70px / 30px` for `#/Exercise/Sets/Reps/Rest/⋯`. Each row has a 2px-wide left gutter in the changed-state color (green added, accent replaced, red removed, transparent unchanged) and a matching pale tint background. Replaced rows show `← previous-name` in muted mono. Exercise name uses sans 13px; numeric cells use mono with tabular numerals.
  - **About this plan** card: 2-column grid of bullet points with a tiny green check icon. Pulls from `data.rules`.
- **Right rail (320px) — chat**:
  - Header: "Edit" eyebrow + version pill.
  - Scrollable messages. Each message: small mono label ("you" in accent / "assistant" in muted) + timestamp + message bubble. User messages have a bordered surface background; assistant messages are plain text in muted color.
  - Footer: textarea (placeholder "e.g. swap barbell rows for cables") + "⌘↵ to send" hint + "Send" button.

### 3. My plans (`MyPlans` component)
- **Purpose**: Library/dashboard of saved plans.
- **Layout**: Top nav + centered main (max-width 1000px, 32px/48px padding).
- **Components**:
  - **Header row**: h1 "Your plans" (28px, weight 500, letter-spacing −0.02em) + "+ New plan" primary button.
  - **Filter row**: chips "All / Training / Nutrition" each with a count badge. Active chip has tint background. Right side: tiny "sort updated ↓".
  - **Table**: 6-column grid `40px / 1fr / 100px / 80px / 100px / 30px` for `Kind / Title / Versions / Size / Updated / →`.
    - Kind = colored pill: "T" (accent tint) for training, "N" (green tint) for nutrition.
    - Title row: title (sans 13px) + `#{id}` (mono, faint).
    - Right arrow on hover/always indicates clickable row.

### 4. Generate (`Generate` component)
- **Purpose**: Form for creating a new workout plan.
- **Layout**: Top nav + centered main (max-width 880px).
- **Components**:
  - Eyebrow "New plan" + h1 "Build a workout plan".
  - **Basics card**: 2-column grid of fields: Goal (select), Experience (select), Days / week (number), Session minutes (number), Equipment (select, full width). Each field has an eyebrow label + a 32px-tall pill input.
  - **Focus muscles card** (optional): wrap of small pills — 14 muscle groups. Selected pills use accent tint + accent text + accent border.
  - **Notes card** (optional): textarea showing freeform notes, one per line. Current example: "avoid overhead pressing (shoulder pain) / prefer cables over machines / extra glute focus".
  - **Submit row**: "Build my plan →" primary button, right-aligned.

### 5. Nutrition plan (`Nutrition` component)
- **Purpose**: View a meal plan with macros and constraints.
- **Layout**: Top nav + centered main (max-width 1040px). After header, two sections: full-width macro strip, then 2-column grid (`1fr / 220px`) of meals table + side cards.
- **Components**:
  - **Header**: eyebrow "Meal plan" + h1 title. Right: "Edit" secondary button.
  - **Macro strip**: 4-column card. Each cell: eyebrow + value (mono, 22–28px, tabular numerals) + unit. Protein/Carbs/Fat cells include a 2px bar showing % of calories.
  - **Meals table**: 6-column grid `100px / 1fr / 70px / 50px / 50px / 50px` for `Slot / Name / Cal / P / C / F`. Slot label is uppercase mono accent. Footer row "Daily total" with tinted bg.
  - **Side cards**:
    - "Allergies" — chips in red tint with "never included" hint underneath.
    - "Diet" — single chip.
    - "Status" — green dot + "hits your targets".

### 6. Sign in (`Login` component)
- **Purpose**: Email/password sign in.
- **Layout**: Centered card (360px wide, 32px/28px padding) on the page background.
- **Components**:
  - Wordmark at top, then a 1px divider.
  - Eyebrow "Sign in" + h2 "Welcome back" (18px).
  - Two fields: Email (mono, prefilled placeholder text) and Password (dots, letter-spacing 0.15em). Each has eyebrow label + 32px input.
  - Primary "Sign in" button, full width.
  - "or" divider with hairlines on each side.
  - Secondary "Use a magic link" button, full width.
  - Footer: "no account · create one" (accent on the action).

## Interactions & Behavior
- **Top nav**: Active item gets tinted background. Inactive items are muted. Click navigates.
- **Plan viewer**:
  - Clicking a version in the left rail sets `selVersion`. If not current, the "Restore v{n}" button appears.
  - Clicking a day tab sets `selDay`. The day table updates.
  - Rest days show an empty-state card instead of a table ("No lifting today. Optional: light walking + mobility.")
  - Chat textarea: ⌘↵ submits. New messages append, optimistic.
- **My plans filter**: Clicking a chip filters the list locally (no fetch).
- **Generate muscle chips**: Toggle individually. Current mock shows `["Side Delts", "Glutes"]` selected.
- **No animations specified** — use 120ms ease-out for hover bg-color transitions, otherwise default.

## State Management
Minimal local state per screen. No global store needed for the views themselves; you'll wire your own data layer.

- `PlanViewer`: `selVersion` (number), `selDay` (number, 0-indexed into week array)
- `MyPlans`: `filter` ("all" | "training" | "nutrition")
- `Generate`: form fields + selected muscle set
- `Login`: email/password fields

Data shapes are defined in `ll-data.jsx` — use those as your API contract starting point (training plan, nutrition plan, plan list).

## Design Tokens

### Colors — Light theme
```
--ll-bg:         #f5f3ee   /* page background, warm off-white */
--ll-surface:    #fbfaf6   /* cards, table backgrounds */
--ll-surface-2:  #f0eee9   /* chat rail (slightly deeper) */
--ll-tint:       rgba(20,18,12,0.035)  /* row stripes, active tab */
--ll-ink:        #16181f   /* primary text */
--ll-muted:      #6b6b73   /* secondary text */
--ll-faint:      #a8a8ad   /* tertiary text, timestamps */
--ll-border:     rgba(20,18,12,0.09)   /* hairlines */
```

### Colors — Dark theme
```
--ll-bg:         #0c0d10
--ll-surface:    #131419
--ll-surface-2:  #0f1014
--ll-tint:       rgba(255,255,255,0.035)
--ll-ink:        #ededee
--ll-muted:      #8a8a93
--ll-faint:      #4f4f56
--ll-border:     rgba(255,255,255,0.07)
```

### Accent + semantic
```
--ll-accent:        #4f6bff  /* default — electric blue */
--ll-accent-tint:   rgba(79,107,255, 0.08 light / 0.13 dark)
--ll-accent-line:   rgba(79,107,255, 0.35)

--ll-ok:    #0f9d58 light, #46d28b dark   /* added rows, status dot */
--ll-bad:   #d93636 light, #ff6b6b dark   /* removed rows, allergens */
```

Accent is theme-able; supported palette: `#4f6bff`, `#00c46a`, `#ff7a3d`, `#a056ff`, `#16181f`.

### Typography
- **Sans** (body, headings): `Geist`, fall back to `-apple-system, BlinkMacSystemFont, system-ui, sans-serif`
- **Mono** (labels, numbers, ids, nav): `JetBrains Mono`, fall back to `ui-monospace, SFMono-Regular, Menlo, monospace`
- Use `font-variant-numeric: tabular-nums` on every numeric cell (sets, reps, rest, calories, macros)

**Scale (locked):**
- h1 (landing hero): 68px / 500 / −0.035em / 1.02
- h1 (screen titles): 22–28px / 500 / −0.015 to −0.02em
- Body: 13px / 400 / 1.5
- Small body / table cells: 12.5px
- Mono labels (eyebrows): 10.5px / 500 / +0.12em / uppercase
- Mono tiny (timestamps): 10px

### Spacing & shape
- Border radius: 4px (chips/pills), 5px (buttons/inputs), 6px (cards), 8px (landing hero card, login card)
- Borders: hairline `0.5px solid var(--ll-border)` everywhere
- No shadows except login card (`0 24px 60px -20px rgba(0,0,0,0.08)`)
- Density modifier (multiplies base font sizes): compact 0.88×, regular 1.0×, comfy 1.12×

### Buttons
- **Primary**: `--ll-ink` background, `--ll-bg` text, mono font 11.5px, letter-spacing 0.02em, 28–36px height, 12–18px horizontal padding, radius 5px, no border.
- **Secondary**: transparent background, `--ll-ink` text, `0.5px solid --ll-border`, otherwise identical.

### Pills / chips
- 20px height, 7px horizontal padding, radius 4px, mono 10.5px, 0.5px border, tint background. Accent variant uses `--ll-accent` text + accent border + accent tint.

## Assets
- Wordmark is inline SVG — a triangular "lift" mark + "lyft·logic" text. The center dot is in the accent color. Code is in `ll-shell.jsx` (`Wordmark` component) — feel free to lift it.
- No bitmap images, no photography, no icons beyond the wordmark and a small green check (also inline SVG in `ll-plan-viewer.jsx` → `CheckIcon`).
- Fonts come from Google Fonts (`Geist`, `JetBrains Mono`).

## Files
The bundle includes:
- `LyftLogic Redesign.html` — entry. Loads React + Babel from CDN, sets up the canvas wrapper, theme provider, and tweaks panel. **Reference only — do not deploy.**
- `ll-shell.jsx` — top nav + wordmark + shared atoms (Mono, Eyebrow, Pill, StatCell).
- `ll-plan-viewer.jsx` — the hero plan-viewer screen + DayTab, LiftRow, DiffCount, ChatMsg, CheckIcon, button helpers.
- `ll-screens.jsx` — Landing, MyPlans, Generate, Nutrition, Login, plus SectionHead, Field, MacroStat, ConstraintCard.
- `ll-data.jsx` — mock data (TRAINING_PLAN, NUTRITION_PLAN, PLANS_LIST). Use this as the rough shape of what your API should return.

You can open the HTML file in a browser to see the running prototype. The "Tweaks" panel on the right is a design-tool artifact — strip it from your production build.

## What to skip when porting
- The `<DesignCanvas>` / `<DCSection>` / `<DCArtboard>` wrappers — those exist only to lay the six screens out side-by-side on a pannable canvas. Each `<DCArtboard>`'s child is the actual screen.
- The `TweaksPanel` and `useTweaks` hook — design-tool only.
- The inline-Babel `<script type="text/babel">` setup — use your normal build pipeline.
- Inline `Object.assign(window, { ... })` exports — replace with regular `import`/`export`.
