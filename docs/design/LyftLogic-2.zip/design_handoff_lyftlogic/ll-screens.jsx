// LyftLogic — remaining screens: Landing, MyPlans, Generate, Nutrition, Login

function Landing() {
  return (
    <div style={{ background: "var(--ll-bg)", minHeight: "100%", display: "flex", flexDirection: "column" }}>
      <AppNav active="landing" email="" />
      <main style={{ flex: 1, padding: "120px 64px 80px", maxWidth: 900, margin: "0 auto", width: "100%", boxSizing: "border-box" }}>
        <h1 style={{
          margin: 0, fontSize: 68, fontWeight: 500, letterSpacing: "-0.035em",
          lineHeight: 1.02, color: "var(--ll-ink)",
        }}>
          Workout and meal plans,<br/>
          <span style={{ color: "var(--ll-muted)" }}>built for you.</span>
        </h1>
        <p style={{
          margin: "28px 0 36px", maxWidth: 520, fontSize: 16, lineHeight: 1.6,
          color: "var(--ll-muted)",
        }}>
          Tell us your goal, your gear, and how much time you have. We'll build a weekly plan you can edit, save, and come back to.
        </p>
        <div style={{ display: "flex", gap: 10 }}>
          <button style={{ ...btnPrimary(), height: 36, padding: "0 16px", fontSize: 12.5 }}>Get started →</button>
          <button style={{ ...btnSecondary(), height: 36, padding: "0 16px", fontSize: 12.5 }}>Sign in</button>
        </div>
      </main>
    </div>
  );
}

// ---------- My Plans dashboard ----------
function MyPlans() {
  const [filter, setFilter] = useState("all");
  const plans = PLANS_LIST.filter(p =>
    filter === "all" ? true : filter === "training" ? p.kind === "T" : p.kind === "N"
  );
  return (
    <div style={{ background: "var(--ll-bg)", minHeight: "100%" }}>
      <AppNav active="plans"/>
      <main style={{ padding: "32px 48px", maxWidth: 1000, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <h1 style={{ margin: 0, fontSize: 28, fontWeight: 500, letterSpacing: "-0.02em" }}>Your plans</h1>
          <button style={{ ...btnPrimary(), height: 32, fontSize: 12 }}>+ New plan</button>
        </div>

        <div style={{ display: "flex", gap: 4, marginBottom: 16, alignItems: "center" }}>
          {[
            ["all", "All", PLANS_LIST.length],
            ["training", "Training", PLANS_LIST.filter(p => p.kind === "T").length],
            ["nutrition", "Nutrition", PLANS_LIST.filter(p => p.kind === "N").length],
          ].map(([k, l, n]) => (
            <button key={k} onClick={() => setFilter(k)} style={{
              padding: "5px 10px", borderRadius: 5, border: 0, cursor: "pointer",
              background: filter === k ? "var(--ll-tint)" : "transparent",
              color: filter === k ? "var(--ll-ink)" : "var(--ll-muted)",
              fontFamily: "var(--ll-mono)", fontSize: 11.5,
              display: "inline-flex", gap: 6, alignItems: "center",
            }}>
              <span>{l}</span>
              <Mono style={{ color: "var(--ll-faint)", fontSize: 10.5 }}>{n}</Mono>
            </button>
          ))}
          <div style={{ marginLeft: "auto", display: "flex", alignItems: "center", gap: 6 }}>
            <Mono style={{ fontSize: 10.5, color: "var(--ll-faint)" }}>sort</Mono>
            <Mono style={{ fontSize: 11.5, color: "var(--ll-muted)" }}>updated ↓</Mono>
          </div>
        </div>

        <div style={{ border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)", overflow: "hidden" }}>
          <div style={{
            display: "grid",
            gridTemplateColumns: "40px 1fr 100px 80px 100px 30px",
            padding: "10px 18px",
            background: "var(--ll-tint)",
            borderBottom: "0.5px solid var(--ll-border)",
          }}>
            <Eyebrow style={{ fontSize: 9.5 }}>Kind</Eyebrow>
            <Eyebrow style={{ fontSize: 9.5 }}>Title</Eyebrow>
            <Eyebrow style={{ fontSize: 9.5 }}>Versions</Eyebrow>
            <Eyebrow style={{ fontSize: 9.5 }}>Size</Eyebrow>
            <Eyebrow style={{ fontSize: 9.5 }}>Updated</Eyebrow>
            <Eyebrow style={{ fontSize: 9.5 }}> </Eyebrow>
          </div>
          {plans.map((p, i) => (
            <div key={p.id} style={{
              display: "grid",
              gridTemplateColumns: "40px 1fr 100px 80px 100px 30px",
              padding: "14px 18px",
              borderBottom: i < plans.length - 1 ? "0.5px solid var(--ll-border)" : 0,
              alignItems: "center", cursor: "pointer",
            }}>
              <Pill style={{
                height: 18, padding: "0 6px", fontSize: 9.5,
                color: p.kind === "T" ? "var(--ll-accent)" : "var(--ll-ok)",
                borderColor: p.kind === "T" ? "var(--ll-accent-line)" : "var(--ll-ok-line)",
                background: p.kind === "T" ? "var(--ll-accent-tint)" : "var(--ll-ok-tint)",
              }}>{p.kind}</Pill>
              <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                <span style={{ fontSize: 13, color: "var(--ll-ink)" }}>{p.title}</span>
                <Mono style={{ fontSize: 10.5, color: "var(--ll-faint)" }}>#{p.id}</Mono>
              </div>
              <Mono style={{ fontSize: 12, color: "var(--ll-muted)" }}>v{p.v}</Mono>
              <Mono style={{ fontSize: 12, color: "var(--ll-muted)" }}>{p.kind === "T" ? `${p.days}d` : `${p.meals}m`}</Mono>
              <Mono style={{ fontSize: 12, color: "var(--ll-muted)" }}>{p.edited}</Mono>
              <span style={{ color: "var(--ll-faint)", textAlign: "right" }}>→</span>
            </div>
          ))}
        </div>
      </main>
    </div>
  );
}

// ---------- Generate ----------
function Generate() {
  const muscles = ["Chest","Back","Lats","Shoulders","Side Delts","Rear Delts","Biceps","Triceps","Upper Back","Quads","Hamstrings","Glutes","Calves","Abs"];
  const sel = ["Side Delts", "Glutes"];
  return (
    <div style={{ background: "var(--ll-bg)", minHeight: "100%" }}>
      <AppNav active="generate"/>
      <main style={{ padding: "32px 48px", maxWidth: 880, margin: "0 auto" }}>
        <Eyebrow>New plan</Eyebrow>
        <h1 style={{ margin: "6px 0 28px", fontSize: 28, fontWeight: 500, letterSpacing: "-0.02em" }}>Build a workout plan</h1>

        <div style={{ border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)", marginBottom: 14 }}>
          <SectionHead label="Basics" />
          <div style={{ padding: "18px 20px", display: "grid", gridTemplateColumns: "1fr 1fr", gap: "16px 20px" }}>
            <Field label="Goal" value="Hypertrophy" select/>
            <Field label="Experience" value="Intermediate" select/>
            <Field label="Days / week" value="4" mono/>
            <Field label="Session minutes" value="60" mono/>
            <div style={{ gridColumn: "span 2" }}><Field label="Equipment" value="Full gym" select/></div>
          </div>
        </div>

        <div style={{ border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)", marginBottom: 14 }}>
          <SectionHead label="Focus muscles" hint="optional"/>
          <div style={{ padding: "16px 20px", display: "flex", flexWrap: "wrap", gap: 6 }}>
            {muscles.map(m => (
              <button key={m} style={{
                padding: "5px 10px", borderRadius: 4, cursor: "pointer",
                fontFamily: "var(--ll-mono)", fontSize: 11,
                border: sel.includes(m) ? "0.5px solid var(--ll-accent-line)" : "0.5px solid var(--ll-border)",
                background: sel.includes(m) ? "var(--ll-accent-tint)" : "transparent",
                color: sel.includes(m) ? "var(--ll-accent)" : "var(--ll-muted)",
              }}>{m}</button>
            ))}
          </div>
        </div>

        <div style={{ border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)", marginBottom: 18 }}>
          <SectionHead label="Notes" hint="optional"/>
          <div style={{ padding: "12px 20px" }}>
            <pre style={{
              margin: 0, fontFamily: "var(--ll-mono)", fontSize: 12,
              color: "var(--ll-muted)", lineHeight: 1.7, whiteSpace: "pre-wrap",
            }}>{`avoid overhead pressing (shoulder pain)
prefer cables over machines
extra glute focus`}</pre>
          </div>
        </div>

        <div style={{ display: "flex", justifyContent: "flex-end", alignItems: "center" }}>
          <button style={{ ...btnPrimary(), height: 36, padding: "0 18px", fontSize: 12 }}>Build my plan →</button>
        </div>
      </main>
    </div>
  );
}

function SectionHead({ label, hint }) {
  return (
    <div style={{
      padding: "12px 20px", borderBottom: "0.5px solid var(--ll-border)",
      display: "flex", alignItems: "center", justifyContent: "space-between",
    }}>
      <Eyebrow>{label}</Eyebrow>
      {hint && <Mono style={{ fontSize: 10.5, color: "var(--ll-faint)" }}>{hint}</Mono>}
    </div>
  );
}

function Field({ label, value, mono, select }) {
  return (
    <label style={{ display: "flex", flexDirection: "column", gap: 6 }}>
      <Eyebrow style={{ fontSize: 9.5 }}>{label}</Eyebrow>
      <div style={{
        height: 32, padding: "0 12px",
        background: "var(--ll-bg)",
        border: "0.5px solid var(--ll-border)", borderRadius: 5,
        display: "flex", alignItems: "center", justifyContent: "space-between",
        fontFamily: mono ? "var(--ll-mono)" : "var(--ll-sans)",
        fontSize: 13, color: "var(--ll-ink)",
        fontVariantNumeric: "tabular-nums",
      }}>
        {value}
        {select && <span style={{ color: "var(--ll-faint)", fontSize: 10 }}>▾</span>}
      </div>
    </label>
  );
}

// ---------- Nutrition ----------
function Nutrition() {
  const d = NUTRITION_PLAN;
  return (
    <div style={{ background: "var(--ll-bg)", minHeight: "100%" }}>
      <AppNav active="nutrition"/>
      <main style={{ padding: "32px 48px", maxWidth: 1040, margin: "0 auto" }}>
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end", marginBottom: 24 }}>
          <div>
            <Eyebrow>Meal plan</Eyebrow>
            <h1 style={{ margin: "6px 0 0", fontSize: 24, fontWeight: 500, letterSpacing: "-0.015em" }}>{d.title}</h1>
          </div>
          <button style={{ ...btnSecondary(), height: 28, fontSize: 11.5 }}>Edit</button>
        </div>

        <div style={{
          border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)",
          padding: "20px 24px", marginBottom: 14,
          display: "grid", gridTemplateColumns: "repeat(4, 1fr)", gap: 0,
        }}>
          <MacroStat label="Calories" value={d.cals} unit="kcal" big/>
          <MacroStat label="Protein" value={d.protein} unit="g" pct={(d.protein*4)/d.cals}/>
          <MacroStat label="Carbs"   value={d.carbs}   unit="g" pct={(d.carbs*4)/d.cals}/>
          <MacroStat label="Fat"     value={d.fat}     unit="g" pct={(d.fat*9)/d.cals}/>
        </div>

        <div style={{
          display: "grid", gridTemplateColumns: "1fr 220px", gap: 14, marginBottom: 14,
        }}>
          <div style={{ border: "0.5px solid var(--ll-border)", borderRadius: 6, background: "var(--ll-surface)", overflow: "hidden" }}>
            <SectionHead label="Meals" hint={`${d.meals.length} slots`}/>
            <div>
              {d.meals.map((m, i) => (
                <div key={i} style={{
                  display: "grid",
                  gridTemplateColumns: "100px 1fr 70px 50px 50px 50px",
                  padding: "14px 20px",
                  borderBottom: i < d.meals.length - 1 ? "0.5px solid var(--ll-border)" : 0,
                  alignItems: "center", gap: 12,
                }}>
                  <Mono style={{ fontSize: 11, color: "var(--ll-accent)", letterSpacing: "0.05em", textTransform: "uppercase" }}>
                    {m.slot}
                  </Mono>
                  <span style={{ fontSize: 13, color: "var(--ll-ink)" }}>{m.name}</span>
                  <Mono style={{ fontSize: 12.5, fontVariantNumeric: "tabular-nums" }}>{m.cal}</Mono>
                  <Mono style={{ fontSize: 11.5, color: "var(--ll-muted)" }}>P{m.p}</Mono>
                  <Mono style={{ fontSize: 11.5, color: "var(--ll-muted)" }}>C{m.c}</Mono>
                  <Mono style={{ fontSize: 11.5, color: "var(--ll-muted)" }}>F{m.f}</Mono>
                </div>
              ))}
              <div style={{
                padding: "12px 20px", background: "var(--ll-tint)",
                display: "flex", justifyContent: "space-between", alignItems: "center",
              }}>
                <Eyebrow style={{ fontSize: 9.5 }}>Daily total</Eyebrow>
                <Mono style={{ fontSize: 12.5 }}>
                  {d.meals.reduce((a,m) => a+m.cal, 0)} kcal · target {d.cals}
                </Mono>
              </div>
            </div>
          </div>

          <div style={{ display: "flex", flexDirection: "column", gap: 14 }}>
            <ConstraintCard title="Allergies" items={d.allergies} bad/>
            <ConstraintCard title="Diet" items={[d.diet]} />
            <div style={{
              border: "0.5px solid var(--ll-border)", borderRadius: 6,
              background: "var(--ll-surface)", padding: "14px 16px",
            }}>
              <Eyebrow style={{ marginBottom: 8 }}>Status</Eyebrow>
              <Mono style={{ fontSize: 11, color: "var(--ll-ok)", display: "flex", alignItems: "center", gap: 6 }}>
                <span style={{ width: 5, height: 5, borderRadius: "50%", background: "var(--ll-ok)" }}/>
                hits your targets
              </Mono>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}

function MacroStat({ label, value, unit, pct, big }) {
  return (
    <div style={{ borderRight: "0.5px solid var(--ll-border)", paddingLeft: 12 }}>
      <Eyebrow>{label}</Eyebrow>
      <div style={{ display: "flex", alignItems: "baseline", gap: 4, marginTop: 6 }}>
        <Mono style={{
          fontSize: big ? 28 : 22, fontWeight: 500,
          letterSpacing: "-0.02em", color: "var(--ll-ink)",
          fontVariantNumeric: "tabular-nums",
        }}>{value.toLocaleString()}</Mono>
        <Mono style={{ fontSize: 11, color: "var(--ll-faint)" }}>{unit}</Mono>
      </div>
      {pct != null && (
        <div style={{ marginTop: 8 }}>
          <div style={{ height: 2, background: "var(--ll-border)", borderRadius: 2, overflow: "hidden" }}>
            <div style={{ height: "100%", width: `${Math.round(pct*100)}%`, background: "var(--ll-accent)" }}/>
          </div>
          <Mono style={{ fontSize: 10, color: "var(--ll-faint)", marginTop: 4, display: "block" }}>
            {Math.round(pct*100)}% kcal
          </Mono>
        </div>
      )}
    </div>
  );
}

function ConstraintCard({ title, items, bad }) {
  return (
    <div style={{
      border: "0.5px solid var(--ll-border)", borderRadius: 6,
      background: "var(--ll-surface)", padding: "14px 16px",
    }}>
      <Eyebrow style={{ marginBottom: 8 }}>{title}</Eyebrow>
      <div style={{ display: "flex", flexWrap: "wrap", gap: 4 }}>
        {items.map((x, i) => (
          <Pill key={i} style={bad ? {
            color: "var(--ll-bad)", borderColor: "var(--ll-bad-line)", background: "var(--ll-bad-tint)",
          } : {}}>{x}</Pill>
        ))}
      </div>
      {bad && <Mono style={{ fontSize: 10, color: "var(--ll-faint)", marginTop: 8, display: "block" }}>never included</Mono>}
    </div>
  );
}

// ---------- Login ----------
function Login() {
  return (
    <div style={{
      background: "var(--ll-bg)", minHeight: "100%",
      display: "flex", alignItems: "center", justifyContent: "center",
      padding: 48,
    }}>
      <div style={{
        width: 360, padding: "32px 28px",
        background: "var(--ll-surface)",
        border: "0.5px solid var(--ll-border)",
        borderRadius: 8,
        boxShadow: "0 24px 60px -20px rgba(0,0,0,0.08)",
      }}>
        <Wordmark size={16}/>
        <div style={{ height: 1, background: "var(--ll-border)", margin: "20px 0" }}/>
        <Eyebrow>Sign in</Eyebrow>
        <h2 style={{ margin: "8px 0 24px", fontSize: 18, fontWeight: 500, letterSpacing: "-0.01em" }}>
          Welcome back
        </h2>
        <Eyebrow style={{ fontSize: 9.5, marginBottom: 6 }}>Email</Eyebrow>
        <div style={{
          height: 32, padding: "0 12px", borderRadius: 5,
          border: "0.5px solid var(--ll-border)", background: "var(--ll-bg)",
          fontFamily: "var(--ll-mono)", fontSize: 12.5, display: "flex", alignItems: "center",
          color: "var(--ll-muted)",
          marginBottom: 12,
        }}>you@lyftlogic.dev</div>
        <Eyebrow style={{ fontSize: 9.5, marginBottom: 6 }}>Password</Eyebrow>
        <div style={{
          height: 32, padding: "0 12px", borderRadius: 5,
          border: "0.5px solid var(--ll-border)", background: "var(--ll-bg)",
          fontFamily: "var(--ll-mono)", fontSize: 12.5, display: "flex", alignItems: "center",
          letterSpacing: "0.15em",
          marginBottom: 20,
        }}>••••••••••</div>
        <button style={{ ...btnPrimary(), height: 34, width: "100%", fontSize: 12 }}>Sign in</button>
        <div style={{
          display: "flex", alignItems: "center", gap: 8,
          margin: "20px 0", color: "var(--ll-faint)",
        }}>
          <div style={{ flex: 1, height: 1, background: "var(--ll-border)" }}/>
          <Mono style={{ fontSize: 10 }}>or</Mono>
          <div style={{ flex: 1, height: 1, background: "var(--ll-border)" }}/>
        </div>
        <button style={{ ...btnSecondary(), height: 34, width: "100%", fontSize: 12 }}>Use a magic link</button>
        <Mono style={{ fontSize: 10.5, color: "var(--ll-faint)", marginTop: 18, textAlign: "center", display: "block" }}>
          no account · <span style={{ color: "var(--ll-accent)", cursor: "pointer" }}>create one</span>
        </Mono>
      </div>
    </div>
  );
}

window.Landing = Landing;
window.MyPlans = MyPlans;
window.Generate = Generate;
window.Nutrition = Nutrition;
window.Login = Login;
