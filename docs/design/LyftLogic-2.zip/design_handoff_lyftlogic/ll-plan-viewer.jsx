// LyftLogic redesign — Plan Viewer (the hero screen)

function PlanViewer({ data, withChat = true }) {
  const [selVersion, setSelVersion] = useState(data.versions[0].v);
  const [selDay, setSelDay] = useState(0);
  const versionItem = data.versions.find(v => v.v === selVersion);
  const isOld = !versionItem?.current;
  const day = data.week[selDay];

  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: withChat ? "200px 1fr 320px" : "200px 1fr",
      height: "100%",
      background: "var(--ll-bg)",
      color: "var(--ll-ink)",
      fontFamily: "var(--ll-sans)",
    }}>
      {/* LEFT: version rail */}
      <aside style={{
        borderRight: "0.5px solid var(--ll-border)",
        padding: "20px 16px",
        display: "flex", flexDirection: "column", gap: 18,
        overflow: "auto",
      }}>
        <div>
          <Eyebrow>Plan</Eyebrow>
          <Mono style={{ fontSize: 13, color: "var(--ll-ink)", marginTop: 4, display: "block" }}>
            {data.id}
          </Mono>
        </div>

        <div>
          <Eyebrow style={{ marginBottom: 10 }}>History</Eyebrow>
          <div style={{ display: "flex", flexDirection: "column", gap: 1 }}>
            {data.versions.map((v) => {
              const active = v.v === selVersion;
              return (
                <button key={v.v} onClick={() => setSelVersion(v.v)} style={{
                  textAlign: "left", border: 0, cursor: "pointer",
                  padding: "8px 9px", borderRadius: 5,
                  background: active ? "var(--ll-tint)" : "transparent",
                  display: "flex", alignItems: "flex-start", gap: 10,
                  fontFamily: "inherit",
                }}>
                  <Mono style={{
                    fontSize: 11, color: active ? "var(--ll-accent)" : "var(--ll-muted)",
                    width: 24, flexShrink: 0, marginTop: 1,
                    fontVariantNumeric: "tabular-nums",
                  }}>v{v.v}</Mono>
                  <div style={{ minWidth: 0, flex: 1 }}>
                    <div style={{
                      fontSize: 11.5, color: active ? "var(--ll-ink)" : "var(--ll-muted)",
                      lineHeight: 1.4, marginBottom: 2,
                    }}>{v.note}</div>
                    <Mono style={{ fontSize: 10, color: "var(--ll-faint)" }}>{v.ts}</Mono>
                  </div>
                  {v.current && <Pill accent style={{ height: 16, padding: "0 5px", fontSize: 9.5 }}>NOW</Pill>}
                </button>
              );
            })}
          </div>
        </div>
      </aside>

      {/* CENTER: plan */}
      <main style={{ overflow: "auto", padding: "24px 32px" }}>
        {/* Run header bar */}
        <div style={{
          display: "flex", alignItems: "center", justifyContent: "space-between",
          paddingBottom: 18,
          borderBottom: "0.5px solid var(--ll-border)",
          marginBottom: 22,
        }}>
          <div>
            <Eyebrow>Workout plan</Eyebrow>
            <h1 style={{
              margin: "6px 0 0", fontSize: 22, fontWeight: 500,
              letterSpacing: "-0.015em",
            }}>{data.title}</h1>
          </div>
          <div style={{ display: "flex", gap: 8, alignItems: "center" }}>
            {isOld && (
              <button style={btnSecondary()}>
                Restore v{selVersion}
              </button>
            )}
            <button style={btnPrimary()}>Edit plan</button>
          </div>
        </div>

        {/* Meta grid */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(6, 1fr)",
          gap: 0,
          border: "0.5px solid var(--ll-border)",
          borderRadius: 6,
          background: "var(--ll-surface)",
          padding: "14px 18px",
          marginBottom: 18,
        }}>
          <StatCell label="Goal" value={data.meta.goal} mono={false} />
          <StatCell label="Level" value={data.meta.experience} mono={false} />
          <StatCell label="Days/wk" value={data.meta.days} />
          <StatCell label="Session" value={`${data.meta.minutes}m`} />
          <StatCell label="Equipment" value={data.meta.equipment} mono={false} />
          <StatCell label="Version" value={`v${selVersion}`} />
        </div>

        {/* Diff strip */}
        {data.diff && (
          <div style={{
            display: "flex", gap: 0,
            background: "var(--ll-surface)",
            border: "0.5px solid var(--ll-border)",
            borderRadius: 6,
            padding: "10px 14px", marginBottom: 18,
            alignItems: "center", justifyContent: "space-between",
            fontSize: 12,
          }}>
            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <Eyebrow>What changed</Eyebrow>
              <DiffCount n={data.diff.added.length} kind="added"/>
              <DiffCount n={data.diff.replaced.length} kind="replaced"/>
              <DiffCount n={data.diff.removed.length} kind="removed"/>
            </div>
            <Mono style={{ color: "var(--ll-muted)", fontSize: 11 }}>{data.versions[0].note}</Mono>
          </div>
        )}

        {/* Week tabs */}
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(7, 1fr)", gap: 4,
          marginBottom: 16,
        }}>
          {data.week.map((d, i) => (
            <DayTab key={i} d={d} idx={i} selected={selDay === i} onClick={() => setSelDay(i)} />
          ))}
        </div>

        {/* Selected day */}
        <DaySection day={day} />

        {/* Rules card */}
        <div style={{
          marginTop: 22,
          border: "0.5px solid var(--ll-border)",
          background: "var(--ll-surface)",
          borderRadius: 6,
          padding: "16px 18px",
        }}>
          <Eyebrow style={{ marginBottom: 10 }}>About this plan</Eyebrow>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "8px 24px" }}>
            {data.rules.map((r, i) => (
              <div key={i} style={{ display: "flex", gap: 8, alignItems: "center", fontSize: 12.5 }}>
                <CheckIcon />
                <span style={{ color: "var(--ll-ink)" }}>{r}</span>
              </div>
            ))}
          </div>
        </div>
      </main>

      {/* RIGHT: chat */}
      {withChat && (
        <aside style={{
          borderLeft: "0.5px solid var(--ll-border)",
          display: "flex", flexDirection: "column",
          background: "var(--ll-surface-2)",
        }}>
          <div style={{
            padding: "14px 18px",
            borderBottom: "0.5px solid var(--ll-border)",
            display: "flex", alignItems: "center", justifyContent: "space-between",
          }}>
            <Eyebrow>Edit</Eyebrow>
            <Pill style={{ height: 18 }}>v{selVersion}</Pill>
          </div>
          <div style={{ flex: 1, overflow: "auto", padding: "16px 18px", display: "flex", flexDirection: "column", gap: 14 }}>
            {data.chat.map((m, i) => (
              <ChatMsg key={i} m={m}/>
            ))}
          </div>
          <div style={{
            padding: 14, borderTop: "0.5px solid var(--ll-border)",
            display: "flex", flexDirection: "column", gap: 10,
          }}>
            <textarea placeholder="e.g. swap barbell rows for cables" rows={3} style={{
              width: "100%", boxSizing: "border-box",
              padding: 10, borderRadius: 5,
              border: "0.5px solid var(--ll-border)",
              background: "var(--ll-bg)", color: "var(--ll-ink)",
              fontFamily: "var(--ll-sans)", fontSize: 12.5,
              resize: "none", outline: "none",
            }}/>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
              <Mono style={{ color: "var(--ll-faint)", fontSize: 10 }}>⌘↵ to send</Mono>
              <button style={btnPrimary()}>Send</button>
            </div>
          </div>
        </aside>
      )}
    </div>
  );
}

function DiffCount({ n, kind }) {
  const cfg = {
    added:    { c: "var(--ll-ok)",     sym: "+" },
    replaced: { c: "var(--ll-accent)", sym: "~" },
    removed:  { c: "var(--ll-bad)",    sym: "−" },
  }[kind];
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
      <Mono style={{
        color: cfg.c, fontWeight: 500, fontSize: 12,
        fontVariantNumeric: "tabular-nums",
      }}>{cfg.sym}{n}</Mono>
      <Mono style={{ color: "var(--ll-muted)", fontSize: 11 }}>{kind}</Mono>
    </div>
  );
}

function DayTab({ d, idx, selected, onClick }) {
  const isRest = d.rest;
  return (
    <button onClick={onClick} style={{
      cursor: "pointer", border: 0, padding: "10px 8px",
      background: selected ? "var(--ll-ink)" : "var(--ll-surface)",
      color: selected ? "var(--ll-bg)" : (isRest ? "var(--ll-muted)" : "var(--ll-ink)"),
      borderRadius: 5,
      textAlign: "left", display: "flex", flexDirection: "column", gap: 4,
      fontFamily: "inherit",
      border: selected ? 0 : "0.5px solid var(--ll-border)",
      transition: "background 120ms",
    }}>
      <Mono style={{ fontSize: 10, opacity: selected ? 0.7 : 0.6 }}>
        {String(idx + 1).padStart(2, "0")}·{d.day.toUpperCase()}
      </Mono>
      <span style={{ fontSize: 12, fontWeight: 500, lineHeight: 1.2 }}>
        {isRest ? "Rest" : d.focus.split(" · ")[1] || d.focus}
      </span>
    </button>
  );
}

function DaySection({ day }) {
  if (day.rest) {
    return (
      <div style={{
        border: "0.5px dashed var(--ll-border)",
        borderRadius: 6, padding: "40px 18px",
        textAlign: "center", color: "var(--ll-muted)",
      }}>
        <Eyebrow style={{ marginBottom: 6 }}>{day.day} · Rest day</Eyebrow>
        <div style={{ fontSize: 13 }}>No lifting today. Optional: light walking + mobility.</div>
      </div>
    );
  }
  return (
    <div style={{
      border: "0.5px solid var(--ll-border)",
      borderRadius: 6, overflow: "hidden",
      background: "var(--ll-surface)",
    }}>
      <div style={{
        display: "grid",
        gridTemplateColumns: "32px 1fr 80px 90px 70px 30px",
        padding: "10px 16px",
        borderBottom: "0.5px solid var(--ll-border)",
        background: "var(--ll-tint)",
      }}>
        <Eyebrow style={{ fontSize: 9.5 }}>#</Eyebrow>
        <Eyebrow style={{ fontSize: 9.5 }}>Exercise</Eyebrow>
        <Eyebrow style={{ fontSize: 9.5 }}>Sets</Eyebrow>
        <Eyebrow style={{ fontSize: 9.5 }}>Reps</Eyebrow>
        <Eyebrow style={{ fontSize: 9.5 }}>Rest</Eyebrow>
        <Eyebrow style={{ fontSize: 9.5 }}> </Eyebrow>
      </div>
      {day.lifts.map((l, i) => <LiftRow key={i} l={l} i={i+1} />)}
    </div>
  );
}

function LiftRow({ l, i }) {
  const c = l.changed;
  const bg = c === "added"    ? "var(--ll-ok-tint)"
           : c === "replaced" ? "var(--ll-accent-tint)"
           : c === "removed"  ? "var(--ll-bad-tint)"
           : "transparent";
  const accent = c === "added"    ? "var(--ll-ok)"
               : c === "replaced" ? "var(--ll-accent)"
               : c === "removed"  ? "var(--ll-bad)"
               : "transparent";
  return (
    <div style={{
      display: "grid",
      gridTemplateColumns: "32px 1fr 80px 90px 70px 30px",
      padding: "12px 16px",
      borderBottom: "0.5px solid var(--ll-border)",
      background: bg,
      alignItems: "center",
      position: "relative",
    }}>
      <div style={{ position: "absolute", left: 0, top: 0, bottom: 0, width: 2, background: accent }}/>
      <Mono style={{ fontSize: 11, color: "var(--ll-faint)" }}>{String(i).padStart(2, "0")}</Mono>
      <div style={{ display: "flex", alignItems: "center", gap: 8, minWidth: 0 }}>
        <span style={{ fontSize: 13, color: "var(--ll-ink)" }}>{l.name}</span>
        {l.tag === "compound" && <Pill style={{ height: 16, fontSize: 9.5 }}>COMPOUND</Pill>}
        {c === "replaced" && l.from && (
          <Mono style={{ fontSize: 10.5, color: "var(--ll-muted)" }}>
            ← {l.from}
          </Mono>
        )}
      </div>
      <Mono style={{ fontSize: 12.5, fontVariantNumeric: "tabular-nums" }}>{l.sets}</Mono>
      <Mono style={{ fontSize: 12.5, fontVariantNumeric: "tabular-nums" }}>{l.reps}</Mono>
      <Mono style={{ fontSize: 12.5, fontVariantNumeric: "tabular-nums", color: "var(--ll-muted)" }}>{l.rest}s</Mono>
      <span style={{ color: "var(--ll-faint)", fontSize: 13, textAlign: "right", cursor: "pointer" }}>⋯</span>
    </div>
  );
}

function ChatMsg({ m }) {
  const isYou = m.who === "you";
  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
      <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
        <Mono style={{
          fontSize: 10, fontWeight: 500,
          color: isYou ? "var(--ll-accent)" : "var(--ll-muted)",
          letterSpacing: "0.08em", textTransform: "uppercase",
        }}>{isYou ? "you" : "assistant"}</Mono>
        <Mono style={{ fontSize: 9.5, color: "var(--ll-faint)" }}>{m.t}</Mono>
      </div>
      <div style={{
        fontSize: 12.5, lineHeight: 1.5,
        color: isYou ? "var(--ll-ink)" : "var(--ll-muted)",
        padding: isYou ? "8px 10px" : 0,
        background: isYou ? "var(--ll-bg)" : "transparent",
        borderRadius: 5,
        border: isYou ? "0.5px solid var(--ll-border)" : "0",
      }}>{m.msg}</div>
    </div>
  );
}

function CheckIcon() {
  return (
    <svg width="11" height="11" viewBox="0 0 12 12" fill="none" style={{ flexShrink: 0 }}>
      <path d="M2.5 6.5L4.8 8.5L9.5 3.8" stroke="var(--ll-ok)" strokeWidth="1.4" strokeLinecap="round" strokeLinejoin="round"/>
    </svg>
  );
}

function btnPrimary() {
  return {
    height: 28, padding: "0 12px", border: 0, cursor: "pointer",
    background: "var(--ll-ink)", color: "var(--ll-bg)",
    fontFamily: "var(--ll-mono)", fontSize: 11.5, letterSpacing: "0.02em",
    fontWeight: 500, borderRadius: 5,
  };
}

function btnSecondary() {
  return {
    height: 28, padding: "0 12px", cursor: "pointer",
    background: "transparent", color: "var(--ll-ink)",
    border: "0.5px solid var(--ll-border)",
    fontFamily: "var(--ll-mono)", fontSize: 11.5, letterSpacing: "0.02em",
    fontWeight: 500, borderRadius: 5,
  };
}

window.PlanViewer = PlanViewer;
window.btnPrimary = btnPrimary;
window.btnSecondary = btnSecondary;
