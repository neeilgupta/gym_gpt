// Mock data for LyftLogic redesign

const TRAINING_PLAN = {
  id: "p_4f9b",
  title: "Upper / Lower · Hypertrophy",
  version: 7,
  created: "May 09, 2026 · 18:42",
  meta: { goal: "Hypertrophy", experience: "Intermediate", days: 4, minutes: 60, equipment: "Full gym" },
  focus: ["Side delts", "Glutes"],
  rules: [
    "Big lifts first, accessories after",
    "Long rest on heavy lifts (4 min)",
    "2 working sets per exercise",
    "Built around your gear and time",
  ],
  week: [
    { day: "Mon", focus: "Upper · Push-led", rest: false, lifts: [
      { name: "Barbell Bench Press", sets: 2, reps: "5–8", rest: 240, tag: "compound", changed: null },
      { name: "Seated Cable Row", sets: 2, reps: "8–12", rest: 180, tag: "compound", changed: null },
      { name: "Standing Overhead Press", sets: 2, reps: "6–10", rest: 240, tag: "compound", changed: null },
      { name: "Cable Lateral Raise", sets: 3, reps: "12–15", rest: 90, tag: "isolation", changed: "added" },
      { name: "Incline DB Curl", sets: 2, reps: "10–12", rest: 90, tag: "isolation", changed: null },
    ]},
    { day: "Tue", focus: "Lower · Glute-bias", rest: false, lifts: [
      { name: "Barbell Hip Thrust", sets: 3, reps: "6–10", rest: 240, tag: "compound", changed: null },
      { name: "Back Squat", sets: 2, reps: "5–8", rest: 240, tag: "compound", changed: null },
      { name: "Romanian Deadlift", sets: 2, reps: "8–10", rest: 180, tag: "compound", changed: null },
      { name: "Cable Kickback", sets: 2, reps: "12–15", rest: 90, tag: "isolation", changed: "replaced", from: "Hip Abduction Machine" },
      { name: "Standing Calf Raise", sets: 2, reps: "10–15", rest: 90, tag: "isolation", changed: null },
    ]},
    { day: "Wed", focus: "Rest", rest: true, lifts: [] },
    { day: "Thu", focus: "Upper · Pull-led", rest: false, lifts: [
      { name: "Weighted Pull-up", sets: 2, reps: "5–8", rest: 240, tag: "compound", changed: null },
      { name: "Incline DB Press", sets: 2, reps: "8–10", rest: 180, tag: "compound", changed: null },
      { name: "Chest-Supported Row", sets: 2, reps: "8–12", rest: 180, tag: "compound", changed: null },
      { name: "Machine Lateral Raise", sets: 3, reps: "12–15", rest: 90, tag: "isolation", changed: null },
      { name: "Cable Tricep Pushdown", sets: 2, reps: "10–12", rest: 90, tag: "isolation", changed: "removed" },
    ]},
    { day: "Fri", focus: "Lower · Quad-bias", rest: false, lifts: [
      { name: "Front Squat", sets: 2, reps: "5–8", rest: 240, tag: "compound", changed: null },
      { name: "Bulgarian Split Squat", sets: 2, reps: "8–10", rest: 180, tag: "compound", changed: null },
      { name: "Leg Press", sets: 2, reps: "10–12", rest: 180, tag: "compound", changed: null },
      { name: "Leg Extension", sets: 2, reps: "12–15", rest: 90, tag: "isolation", changed: null },
      { name: "Seated Calf Raise", sets: 2, reps: "10–15", rest: 90, tag: "isolation", changed: null },
    ]},
    { day: "Sat", focus: "Rest", rest: true, lifts: [] },
    { day: "Sun", focus: "Rest", rest: true, lifts: [] },
  ],
  versions: [
    { v: 7, ts: "May 09 · 18:42", note: "Added side-delt isolation on Mon", current: true },
    { v: 6, ts: "May 08 · 09:11", note: "Avoid shoulders → swapped OHP variant" },
    { v: 5, ts: "May 07 · 22:30", note: "Glute focus" },
    { v: 4, ts: "May 06 · 12:00", note: "Initial restored from v2" },
    { v: 3, ts: "May 05 · 14:08", note: "No barbells (test)" },
    { v: 2, ts: "May 04 · 19:22", note: "Bumped to 4 days" },
    { v: 1, ts: "May 04 · 18:55", note: "Generated" },
  ],
  diff: {
    replaced: [{ day: 2, block: "isolation", from: "Hip Abduction Machine", to: "Cable Kickback" }],
    added:    [{ day: 1, block: "isolation", name: "Cable Lateral Raise" }],
    removed:  [{ day: 4, block: "isolation", name: "Cable Tricep Pushdown" }],
  },
  chat: [
    { who: "you", t: "May 09 · 18:40", msg: "add more side delt work" },
    { who: "assistant", t: "May 09 · 18:40", msg: "Added Cable Lateral Raise to Monday — 3 sets of 12–15, 90s rest." },
    { who: "you", t: "May 09 · 18:41", msg: "swap the abduction machine for something with cables" },
    { who: "assistant", t: "May 09 · 18:41", msg: "Swapped Hip Abduction Machine for Cable Kickback on Tuesday." },
  ],
};

const NUTRITION_PLAN = {
  id: "n_8c2a",
  title: "Maintenance · 2,600 kcal",
  goal: "Maintenance",
  cals: 2600, protein: 140, carbs: 310, fat: 87,
  diet: "None", allergies: ["peanuts", "shellfish"],
  meals: [
    { slot: "Breakfast", name: "Oats + Whey + Honey + Berries", cal: 612, p: 38, c: 84, f: 12 },
    { slot: "Lunch",     name: "Chicken Rice Bowl + Avocado",   cal: 740, p: 45, c: 92, f: 22 },
    { slot: "Snack",     name: "Greek Yogurt + Banana",         cal: 320, p: 22, c: 48, f: 6  },
    { slot: "Dinner",    name: "Sirloin + Sweet Potato + Greens", cal: 728, p: 48, c: 72, f: 26 },
  ],
};

const PLANS_LIST = [
  { kind: "T", id: 412, title: "Upper / Lower · Hypertrophy", v: 7, edited: "2h ago", days: 4 },
  { kind: "T", id: 408, title: "Push Pull Legs · Strength",   v: 3, edited: "5d ago", days: 6 },
  { kind: "N", id: 117, title: "Maintenance · 2,600 kcal",    v: 4, edited: "1d ago", meals: 4 },
  { kind: "T", id: 401, title: "Full Body · Beginner",        v: 1, edited: "2w ago", days: 3 },
  { kind: "N", id: 112, title: "Cut · 2,200 kcal",            v: 2, edited: "3w ago", meals: 4 },
];

Object.assign(window, { TRAINING_PLAN, NUTRITION_PLAN, PLANS_LIST });
