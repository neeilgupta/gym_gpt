// LyftLogic redesign — Plan Viewer (hero screen)
// Engineering dashboard treatment of the deterministic training plan.

const { useState, useMemo } = React;

// -----------------------------------------------------------
// Shared atoms
// -----------------------------------------------------------

const Mono = ({ children, style, ...rest }) => (
  <span style={{ fontFamily: "var(--ll-mono)", letterSpacing: "0.01em", ...style }} {...rest}>{children}</span>
);

const Eyebrow = ({ children, style, ...rest }) => (
  <div style={{
    fontFamily: "var(--ll-mono)",
    fontSize: "10.5px",
    letterSpacing: "0.12em",
    textTransform: "uppercase",
    color: "var(--ll-muted)",
    fontWeight: 500,
    ...style,
  }} {...rest}>{children}</div>
);

const Pill = ({ children, accent, style }) => (
  <span style={{
    display: "inline-flex", alignItems: "center", gap: 6,
    height: 20, padding: "0 7px",
    border: `0.5px solid ${accent ? "var(--ll-accent-line)" : "var(--ll-border)"}`,
    background: accent ? "var(--ll-accent-tint)" : "var(--ll-tint)",
    color: accent ? "var(--ll-accent)" : "var(--ll-ink)",
    fontFamily: "var(--ll-mono)", fontSize: 10.5, letterSpacing: "0.04em",
    borderRadius: 4,
    ...style,
  }}>{children}</span>
);

const StatCell = ({ label, value, mono = true }) => (
  <div style={{ display: "flex", flexDirection: "column", gap: 4 }}>
    <Eyebrow style={{ fontSize: 9.5 }}>{label}</Eyebrow>
    <div style={{
      fontFamily: mono ? "var(--ll-mono)" : "var(--ll-sans)",
      fontSize: 16, fontWeight: 500, color: "var(--ll-ink)",
      letterSpacing: mono ? "0" : "-0.01em",
      fontVariantNumeric: "tabular-nums",
    }}>{value}</div>
  </div>
);

// -----------------------------------------------------------
// Nav (top, app-shell)
// -----------------------------------------------------------

function AppNav({ active = "plans", email = "you@lyftlogic.dev" }) {
  const items = [
    { k: "plans", label: "Plans" },
    { k: "generate", label: "Generate" },
    { k: "nutrition", label: "Nutrition" },
    { k: "settings", label: "Settings" },
  ];
  return (
    <header style={{
      display: "flex", alignItems: "center", justifyContent: "space-between",
      height: 48, padding: "0 24px",
      borderBottom: "0.5px solid var(--ll-border)",
      background: "var(--ll-bg)",
      position: "sticky", top: 0, zIndex: 10,
    }}>
      <div style={{ display: "flex", alignItems: "center", gap: 28 }}>
        <Wordmark size={15} />
        <nav style={{ display: "flex", alignItems: "center", gap: 2 }}>
          {items.map(i => (
            <a key={i.k} href="#" style={{
              fontFamily: "var(--ll-mono)", fontSize: 11.5,
              padding: "6px 10px", borderRadius: 5,
              color: i.k === active ? "var(--ll-ink)" : "var(--ll-muted)",
              background: i.k === active ? "var(--ll-tint)" : "transparent",
              textDecoration: "none",
              letterSpacing: "0.01em",
            }}>{i.label}</a>
          ))}
        </nav>
      </div>
      <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
        <Mono style={{ fontSize: 11, color: "var(--ll-muted)" }}>{email}</Mono>
        <div style={{
          width: 22, height: 22, borderRadius: "50%",
          background: "var(--ll-tint)", border: "0.5px solid var(--ll-border)",
          display: "flex", alignItems: "center", justifyContent: "center",
          fontFamily: "var(--ll-mono)", fontSize: 10, color: "var(--ll-ink)",
        }}>y</div>
      </div>
    </header>
  );
}

function Wordmark({ size = 14 }) {
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 8 }}>
      <svg width={size} height={size} viewBox="0 0 16 16" fill="none">
        <path d="M2 14L8 2L14 14H10.5L8 9L5.5 14H2Z" stroke="var(--ll-ink)" strokeWidth="1.4" strokeLinejoin="miter" fill="none"/>
        <path d="M5.5 14L8 9L10.5 14" stroke="var(--ll-accent)" strokeWidth="1.4" strokeLinejoin="miter" fill="none"/>
      </svg>
      <span style={{
        fontFamily: "var(--ll-mono)", fontSize: size - 1.5,
        fontWeight: 600, letterSpacing: "0.02em", color: "var(--ll-ink)",
      }}>lyft<span style={{ color: "var(--ll-accent)" }}>·</span>logic</span>
    </div>
  );
}

window.Mono = Mono;
window.Eyebrow = Eyebrow;
window.Pill = Pill;
window.StatCell = StatCell;
window.AppNav = AppNav;
window.Wordmark = Wordmark;
